package com.example.klaus.shuimumusic.activity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.example.klaus.shuimumusic.R;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by klaus on 17-5-6.
 */

public class PlayActivity extends AppCompatActivity implements View.OnClickListener{

    private Button playBtn;
    private MediaPlayer mediaPlayer;
    private TextView musicTitle;
    private TextView musicArtist;
    private TextView finalProgress;
    private Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.play_activity);
        findViewById();
        playBtn.setOnClickListener(this);
        initMediaPlayer();
    }

    private void findViewById() {
        playBtn = (Button) findViewById(R.id.play_music);
        musicTitle = (TextView) findViewById(R.id.musicTitle);
        musicArtist = (TextView) findViewById(R.id.musicArtist);
        finalProgress = (TextView) findViewById(R.id.final_progress);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.play_music:
                if (!mediaPlayer.isPlaying()) {
                    playBtn.setBackgroundResource(R.drawable.pause_selector);
                    mediaPlayer.start();
                } else {
                    mediaPlayer.pause();
                    playBtn.setBackgroundResource(R.drawable.play_selector);
                }
                break;
        }
    }

    private void initMediaPlayer() {
        mediaPlayer = new MediaPlayer();
        bundle = getIntent().getExtras();
        String songName = bundle.getString("musicTitle");
        String singer = bundle.getString("musicArtist");
        String finalURL = bundle.getString("finalURL");
        try {
            mediaPlayer.setDataSource(finalURL);
            mediaPlayer.prepare();
            Date date = new Date(mediaPlayer.getDuration());
            musicTitle.setText(songName);
            musicArtist.setText(singer);
            SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
            String times = sdf.format(date);
            Log.d("TAG", "initMediaPlayer: "+times);
            finalProgress.setText(times);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
