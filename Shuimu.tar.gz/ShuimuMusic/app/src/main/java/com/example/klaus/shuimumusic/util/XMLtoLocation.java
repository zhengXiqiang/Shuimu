package com.example.klaus.shuimumusic.util;


import android.os.Message;
import android.util.Log;

import com.example.klaus.shuimumusic.bean.Songs;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;


import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * Created by klaus on 17-5-5.
 */

public class XMLtoLocation {

    String finalURL;
    private static final int SHOW_RESPONSE = 0;
    private List<String> list;

    public XMLtoLocation(URL url) {
        try {
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            InputStream in = connection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            Message message = new Message();
            message.what = SHOW_RESPONSE;
            message.obj = response.toString();
//            Log.d("TAG", "AnalyticalUtil: " + (String) message.obj);
            list = parseXMLWithPull((String) message.obj);
            DecodeKaiserMatrix decodeKaiserMatrix = new DecodeKaiserMatrix(list.get(2));
            finalURL = decodeKaiserMatrix.getFinalURL();
//            Log.d("TAG", "XMLtoLocation: "+finalURL);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String> getSongsList() {
//        Iterator iterator = list.iterator();
//        while (iterator.hasNext()) {
//            Log.d("TAG", "RPK: " + iterator.next());
//        }
        return list;
    }

    public String getLocation() {
        return finalURL;
    }

    public List<String> parseXMLWithPull(String xmlData) {

        List<String> songsList = null;
        Songs songs = new Songs();

        String songName = "";
        String artist = "";
        String location = "";

        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new StringReader(xmlData));
            int eventType = xmlPullParser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                String nodeName = xmlPullParser.getName();
                switch (eventType) {
                    case XmlPullParser.START_TAG: {
                        if ("songName".equals(nodeName)) {
                            songName = xmlPullParser.nextText();
                            songs.setSongName(songName);
                        } else if ("artist".equals(nodeName)) {
                            artist = xmlPullParser.nextText();
                            songs.setArtist(artist);
                        } else if ("location".equals(nodeName)) {
                            location = xmlPullParser.nextText();
                            songs.setLocation(location);
                        }

                        break;
                    }

                    case XmlPullParser.END_TAG: {
                        if ("trackList".equals(nodeName)) {

//                            Log.d("TAG", "parseXMLWithPull: " + songName);
//                            Log.d("TAG", "parseXMLWithPull: " + artist);
//                            Log.d("TAG", "parseXMLWithPull: " + location);

                            songsList = new ArrayList<>();
                            songsList.add(songName);
                            songsList.add(artist);
                            songsList.add(location);
                        }
                        break;
                    }

                    default:
                        break;
                }
                eventType = xmlPullParser.next();
            }


        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return songsList;
    }


}
