package com.example.klaus.shuimumusic.util;


import android.os.Message;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;


import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;


/**
 * Created by klaus on 17-5-2.
 */


public class AnalyticalUtil {

    private static final int SHOW_RESPONSE = 0;
    String finalURL = "";
    String[] data;

    public AnalyticalUtil() {
        try {
            URL url = new URL("http://www.xiami.com/song/playlist/id/1775554286/object_name/default/object_id/0");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            InputStream in = connection.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            Message message = new Message();
            message.what = SHOW_RESPONSE;
            message.obj = response.toString();
            Log.d("TAG", "AnalyticalUtil: " + (String) message.obj);
            data = parseXMLWithPull((String) message.obj);
            String middleLocation = getLocation(data[2]);
            String realLocation = URLDecoder.decode(middleLocation, "utf-8");
            Log.d("TAG", "AnalyticalUtils: " + realLocation);
            finalURL = realLocation.replace("^", "0");
            Log.d("TAG", "AnalyticalUtil: " + finalURL);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public String getFinalURL() {
        return finalURL;
    }
    public String getSongName() {
        return data[0];
    }
    public String getSinger() {
        return data[1];
    }
    public String getAlbumPic() {
        return data[3];
    }

    private String getLocation(String location) {
        boolean flag = true;
        int count = 0;
        String realLocation = "";
        int hang = Integer.parseInt(location.substring(0, 1));          //看第一个数字知行数
        String subLocation = location.substring(1);                 //去掉第一个数字的字符串
        double len = subLocation.length() / hang;                   //一行里的长度
        int minHang = hang - subLocation.length() % hang;                    //少的行数
        int maxH = (int) Math.floor(len) + 1;                            //不能整除向上取整
//        Log.d("TAG", "inversionArr: "+maxH);
        int minH = (int) Math.floor(len);                           //不能整除向下取整
//        Log.d("TAG", "inversionArr: "+minH);
        char[][] element = new char[hang][];        //数组行数下标
        if (subLocation.length() % hang == 0) {
            for (int i = 0; i < subLocation.length(); i = i + minH) {
                element[count++] = subLocation.substring(i, i + minH).toCharArray();
            }
        } else if (subLocation.length() % hang != 0) {
            for (int i = 0; i < subLocation.length() - minHang * minH; i = i + maxH) {
                element[count++] = subLocation.substring(i, i + maxH).toCharArray();
            }
            for (int i = maxH * (hang - minHang); i < subLocation.length(); i = i + minH) {
                element[count++] = subLocation.substring(i, i + minH).toCharArray();
            }
        }
        char[][] arrV = new char[hang][];
        switch (location.substring(0, 1)) {
            case "4":
                arrV = new char[][]{element[0], element[1], element[2], element[3]};
                break;


            case "5":
                arrV = new char[][]{element[0], element[1], element[2], element[3], element[4]};
                break;


            case "6":
                arrV = new char[][]{element[0], element[1], element[2], element[3], element[4], element[5]};
                break;


            case "7":
                arrV = new char[][]{element[0], element[1], element[2], element[3], element[4], element[5], element[6]};
                break;


            case "8":
                arrV = new char[][]{element[0], element[1], element[2], element[3], element[4], element[5], element[6], element[7]};
                break;


            case "9":
                arrV = new char[][]{element[0], element[1], element[2], element[3], element[4], element[5], element[6], element[7], element[8]};
                break;
        }

        char[][] arrR = new char[maxH][hang];

        for (int i = 0; i < arrV.length; i++) {
            for (int j = 0; j < arrV[i].length; j++) {
                arrR[j][i] = arrV[i][j];
//                Log.d("TAG", "getRealLocation: " + arrR[j][i]);
            }
        }

        for (int i = 0; i < arrR.length; i++) {
            for (int j = 0; j < arrR[i].length; j++) {
                realLocation += String.valueOf(arrR[i][j]);
//                Log.d("TAG", "getRealLocation: " + realLocation);
            }
        }

        while (flag) {
            if (!realLocation.endsWith("l")) {
                realLocation = realLocation.substring(0, realLocation.length() - 1);
//                Log.d("TAG", "inversionArr: "+realLocation);
            } else {
                flag = false;
            }
        }
        return realLocation;
    }

    private String[] parseXMLWithPull(String xmlData) {
        String[] datas = new String[0];
        String songName="";
        String singers="";
        String location = "";
        String albumPic = "";
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser xmlPullParser = factory.newPullParser();
            xmlPullParser.setInput(new StringReader(xmlData));
            int eventType = xmlPullParser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                String nodeName = xmlPullParser.getName();
                switch (eventType) {
                    case XmlPullParser.START_TAG: {
                        if ("songName".equals(nodeName)){
                            songName = xmlPullParser.nextText();
                        }
                        else if ("singers".equals(nodeName)){
                            singers = xmlPullParser.nextText();
                        }
                        else if ("location".equals(nodeName)) {
                            location = xmlPullParser.nextText();
                        }
                        else if ("album_pic".equals(nodeName)) {
                            albumPic = xmlPullParser.nextText();
                        }

                        break;
                    }

                    case XmlPullParser.END_TAG: {
                        if ("trackList".equals(nodeName)) {
                            Log.d("TAG", "parseXMLWithPull: " + songName);
                            Log.d("TAG", "parseXMLWithPull: " + singers);
                            Log.d("TAG", "parseXMLWithPull: " + location);
                            Log.d("TAG", "parseXMLWithPull: " + albumPic);
                        }
                        break;
                    }

                    default:
                        break;
                }
                eventType = xmlPullParser.next();
            }
            datas = new String[]{songName, singers, location,albumPic};

        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return datas;
    }

}