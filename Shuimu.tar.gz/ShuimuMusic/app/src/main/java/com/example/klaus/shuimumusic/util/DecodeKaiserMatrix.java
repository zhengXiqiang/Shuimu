package com.example.klaus.shuimumusic.util;

import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * Created by klaus on 17-5-5.
 */

public class DecodeKaiserMatrix {

    private String s;

    public DecodeKaiserMatrix(String location) {
        s = decodeRubust(location);
//        Log.d("TAG", "DecodeKaiserMatrix: "+s);
    }

    public String getFinalURL() {
        return s;
    }

    static public String decodeRubust(String str) {
        if (str == null || str.length() < 1)
            return null;
        int num = Integer.valueOf(str.charAt(0) + "");
        int step = (str.length() - 1) / num;
        int helpStep = step;
        String[] matrix = new String[num];
//        System.out.println(str.length() - 1);

        int duo = (str.length() - 1) % num;

        for (int i = 0, j = 1; i < matrix.length; i++, j = j + helpStep) {
            if (i < duo)
                helpStep = step + 1;
            else
                helpStep = step;

            matrix[i] = str.substring(j, j + helpStep);
//            System.out.println(matrix[i]);
        }
        // print(matrix);

        return makeSense(matrix);

    }

    static private String decode(String str) {
        if (str == null || str.length() < 1)
            return null;
        int num = Integer.valueOf(str.charAt(0) + "");
        // System.out.println(num);
//        System.out.println(str.length() - 1);
        if ((str.length() - 1) % num != 0)
            return null;

        int step = (str.length() - 1) / num;

        String[] matrix = new String[num];
        for (int i = 0, j = 1; i < matrix.length; i++, j = j + step) {
            matrix[i] = str.substring(j, Math.max(j + step, matrix.length));
//            System.out.println(matrix[i]);
        }

        // print(matrix);

        return makeSense(matrix);
    }

    private static String makeSense(String[] matrix) {
        StringBuffer sb = new StringBuffer();
        for (int j = 0; j < matrix[0].length(); j++) {
            for (int i = 0; i < matrix.length; i++) {
                if (matrix[i].length() - 1 >= j)
                    sb.append(matrix[i].charAt(j));
            }
        }

//        System.out.println(sb.toString());

        String tmp = new String();
        try {
            tmp = URLDecoder.decode(sb.toString(), "UTF-8");
            tmp = tmp.replaceAll("\\^", "0");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            tmp = null;
        }

        if (tmp.subSequence(0, 7).equals("http://") && tmp.substring(tmp.length()-6).equals("0-null"))
            return tmp;
        else
            return null;
    }

//    private void print(String[] matrix) {
//        for (int i = 0; i < matrix.length; i++) {
//            System.out.println(matrix[i]);
//        }
//        System.out.println();
//    }

}