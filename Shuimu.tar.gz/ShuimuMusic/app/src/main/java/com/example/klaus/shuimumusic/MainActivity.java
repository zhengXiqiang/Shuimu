package com.example.klaus.shuimumusic;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.klaus.shuimumusic.activity.PlayActivity;
import com.example.klaus.shuimumusic.adapter.SongsAdapter;
import com.example.klaus.shuimumusic.bean.Songs;
import com.example.klaus.shuimumusic.util.AnalyticalUtil;
import com.example.klaus.shuimumusic.util.RPK;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private ImageView album;
    private Button playBtn;     // 播放（播放、暂停）
    private List<Songs> songs;
    private String songName;
    private String singer;
    private String albumPic;
    private MediaPlayer mediaPlayer;
    private TextView finalProgress;
    private TextView musicTitle;
    private TextView musicArtist;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        MyThread t = new MyThread();
        t.start();
        try {
            sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        setContentView(R.layout.activity_main);
        findViewById();
        SongsAdapter songsAdapter = new SongsAdapter(MainActivity.this,R.layout.songs_item,songs);
        mListView.setAdapter(songsAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Songs song = songs.get(position);
                Intent intent = new Intent(MainActivity.this, PlayActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("musicTitle",song.getSongName());
                bundle.putString("musicArtist",song.getArtist());
                bundle.putString("finalURL",song.getLocation());
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
//        playBtn.setOnClickListener(this);
//        initMediaPlayer();

    }

//    private void initMediaPlayer() {
//        mediaPlayer = new MediaPlayer();
//        try {
//            mediaPlayer.setDataSource(finalURL);
//            mediaPlayer.prepare();
//            Date date = new Date(mediaPlayer.getDuration());
//            album.setImageURI(Uri.parse(albumPic));
//            musicTitle.setText(songName);
//            musicArtist.setText(singer);
//            SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
//            String times = sdf.format(date);
//            Log.d("TAG", "initMediaPlayer: "+times);
//            finalProgress.setText(times);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }


    private void findViewById() {
//        playBtn = (Button) findViewById(R.id.play_music);
//        finalProgress = (TextView) findViewById(R.id.final_progress);
//        musicTitle = (TextView) findViewById(R.id.musicTitle);
//        musicArtist = (TextView) findViewById(R.id.musicArtist);
//        album = (ImageView) findViewById(R.id.albumPic);
        mListView = (ListView) findViewById(R.id.music_list);
    }

    @Override
    public void onClick(View v) {
//        switch (v.getId()) {
//            case R.id.play_music:
//                if (!mediaPlayer.isPlaying()) {
//                    playBtn.setBackgroundResource(R.drawable.pause_selector);
//                    mediaPlayer.start();
//                } else {
//                    mediaPlayer.pause();
//                    playBtn.setBackgroundResource(R.drawable.play_selector);
//                }
//                break;
//        }
    }

    class MyThread extends Thread {

        @Override
        public void run() {
            RPK a = new RPK();
            songs = a.getSongs();
//            Iterator iterator = finalURL.iterator();
//            while (iterator.hasNext()) {
//                Log.d("TAG", "M: " + iterator.next());
//            }


//            AnalyticalUtil analyticalUtil = new AnalyticalUtil();
//            finalURL = analyticalUtil.getFinalURL();
//            songName = analyticalUtil.getSongName();
//            singer = analyticalUtil.getSinger();
//            albumPic = analyticalUtil.getAlbumPic();
//            Log.d("TAG", "run: " + albumPic);
        }
    }

}

