package com.example.klaus.shuimumusic.bean;

import android.util.Log;

import com.example.klaus.shuimumusic.util.DecodeKaiserMatrix;
import com.example.klaus.shuimumusic.util.XMLtoLocation;

import java.net.URL;

/**
 * Created by klaus on 17-5-5.
 */

public class Songs {

    private int songId;
    private String songName;
    private int albumId;
    private String albumName;
    private String albumPicURL;
    private int artistId;
    private String artist;
    private String artistURL;
    private String downloadLocation;
    private String lylic;               //歌词

    public Songs() {

    }

    public Songs(URL url) {
        XMLtoLocation xmLtoLocation = new XMLtoLocation(url);
    }

    public int getSongId() {
        return songId;
    }

    public void setSongId(int songId) {
        this.songId = songId;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumPicURL() {
        return albumPicURL;
    }

    public void setAlbumPicURL(String albumPicURL) {
        this.albumPicURL = albumPicURL;
    }

    public int getArtistId() {
        return artistId;
    }

    public void setArtistId(int artistId) {
        this.artistId = artistId;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getArtistURL() {
        return artistURL;
    }

    public void setArtistURL(String artistURL) {
        this.artistURL = artistURL;
    }

    public String getLocation() {
        return downloadLocation;
    }

    public void setLocation(String location) {
        this.downloadLocation = location;
    }

    public String getLylic() {
        return lylic;
    }

    public void setLylic(String lylic) {
        this.lylic = lylic;
    }
}
