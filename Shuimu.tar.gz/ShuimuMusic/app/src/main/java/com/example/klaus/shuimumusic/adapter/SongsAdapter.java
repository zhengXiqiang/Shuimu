package com.example.klaus.shuimumusic.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.klaus.shuimumusic.R;
import com.example.klaus.shuimumusic.bean.Songs;

import java.util.List;

/**
 * Created by klaus on 17-5-6.
 */

public class SongsAdapter extends ArrayAdapter<Songs> {

    private int resourceId;

    public SongsAdapter(Context context, int resource, List<Songs> objects) {
        super(context, resource, objects);
        resourceId = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Songs songs = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceId,null);
        TextView songName = (TextView) view.findViewById(R.id.song_name);
        TextView artist = (TextView) view.findViewById(R.id.artist);
        songName.setText(songs.getSongName());
        artist.setText(songs.getArtist());
        return view;
    }
}
