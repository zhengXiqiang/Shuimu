package com.example.klaus.shuimumusic.util;

/**
 * Created by klaus on 17-5-5.
 */

import android.util.Log;


import com.example.klaus.shuimumusic.bean.Songs;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RPK {

    private String location;
    List<String> songsList;
    List<Songs> song = new ArrayList<Songs>();
    Songs songs;
    private static final int SHOW_RESPONSE = 0;
    private String PATH = "http://www.xiami.com/song/playlist/id/[songid]/object_name/default/object_id/0";

    public RPK() {
        List<String> songsUrl = new ArrayList<>();
        try {
            Document doc = Jsoup.connect("http://www.xiami.com/album/1369631477").followRedirects(true).timeout(10000)
                    .get();
            Elements songs = doc.select("td.chkbox");
            for (Element e : songs) {
                songsUrl.add(e.select("input").attr("value"));

            }
//            Iterator iterator = songsUrl.iterator();
//            while (iterator.hasNext()) {
//                Log.d("TAG", "RPK: " + iterator.next());
//            }
            if (songsUrl.size() > 0) {
                // 根据歌曲 URL 下载
                for (String url : songsUrl)
                    downLoadBySong(url);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void downLoadBySong(String songUrl) {
        try {
            int songId = Integer.valueOf(songUrl);
            String downLocation = PATH.replace("[songid]", songId + "");
            URL url = new URL(downLocation);
//            Log.d("TAG", "downLoadBySong: " + url);

            XMLtoLocation x = new XMLtoLocation(url);
            location = x.getLocation();
            songsList = x.getSongsList();
//            Iterator iterator = songsList.iterator();
//            while (iterator.hasNext()) {
//                Log.d("TAG", "RPK: " + iterator.next());
//            }
            songs  = new Songs();
            songs.setSongName(songsList.get(0));
//            Log.d("TAG", "downLoadBySong: "+songs.getSongName());
            songs.setArtist(songsList.get(1));
//            Log.d("TAG", "downLoadBySong: "+songs.getArtist());
            songs.setLocation(location);
//            Log.d("TAG", "downLoadBySong: "+songs.getLocation());
            song.add(songs);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    public List<Songs> getSongs() {
//        Iterator iterator = song.iterator();
//        while (iterator.hasNext()) {
//            Log.d("TAG", "RPKzzz: " + iterator.next());
//        }
        return song;
    }

}
